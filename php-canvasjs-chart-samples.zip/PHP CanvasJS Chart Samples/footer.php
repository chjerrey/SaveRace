                </div> <!-- /content-->
            </div> <!-- /row -->
        </div> <!-- /container-fluid -->

        <!-- footer -->
        <div id="footer">
            <p class="text-muted">&#169; 2017 fenopix</p>
        </div>
        <!-- /footer -->
    </div>
    <!-- /page-content-wrapper -->

</body>
</html>