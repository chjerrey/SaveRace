<?php highlight_file(basename(urldecode($_GET['target']))); ?>
