# bulma-calendar
Bulma's extension to display a calendar

# :exclamation::exclamation::exclamation: Looking for new Maintainer :exclamation::exclamation::exclamation:
As you may have noticed, this package has not been updated for some time. I'm sorry, but unfortunately I'm not able to continue to maintain it, so I'm looking for someone who would like to take it over and maintain it. If you are interested, please contact me at wikiki@protonmail.com to discuss how to proceed.
