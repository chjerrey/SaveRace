module.exports = {
	globalSetup: './__jest__/setup.js',
	globalTeardown: './__jest__/teardown.js',
	testEnvironment: './__jest__/puppeteer_environment.js',
	// transform: {
	// 	'^.+\\.jsx$': 'babel-jest'
	// }
};