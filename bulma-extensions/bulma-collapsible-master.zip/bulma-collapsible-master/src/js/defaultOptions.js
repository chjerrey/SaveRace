const defaultOptions = {
	allowMultiple: false,
	container: typeof document !== 'undefined' ? document : null
};

export default defaultOptions;